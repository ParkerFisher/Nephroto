package study.amazons3integration.aws;

import com.amazonaws.regions.Regions;

public class AWSKeys {
    protected static final String COGNITO_POOL_ID = "us-east-1:e7db881f-12a5-4026-af95-5df34afd4bbf";
    protected static final Regions MY_REGION = Regions.US_EAST_1; // WHAT EVER REGION IT MAY BE, PLEASE CHOOSE EXACT
    public static final String BUCKET_NAME = "nephbucket";

}
